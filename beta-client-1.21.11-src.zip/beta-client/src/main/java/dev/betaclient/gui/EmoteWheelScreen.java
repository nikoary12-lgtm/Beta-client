package dev.betaclient.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Radial emote wheel. Emotes are chat-based so they work on any server (Donut SMP included). */
public class EmoteWheelScreen extends Screen {
    private static final String[] EMOTES = { "o/ (wave)", "GG", "<3", "xD", "lol", "?!", "GL HF", "o7" };
    private static final String[] SEND   = { "o/", "gg", "<3", "xD", "lol", "?!", "gl hf", "o7" };

    public EmoteWheelScreen() { super(Text.literal("Emotes")); }

    private int hovered(double mx, double my) {
        double dx = mx - width / 2.0, dy = my - height / 2.0;
        if (Math.hypot(dx, dy) < 25) return -1;
        double a = Math.atan2(dy, dx) + Math.PI / 2 + Math.PI / EMOTES.length;
        a = (a + Math.PI * 2) % (Math.PI * 2);
        return (int) (a / (Math.PI * 2 / EMOTES.length)) % EMOTES.length;
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        int cx = width / 2, cy = height / 2, r = 70, hov = hovered(mx, my);
        for (int i = 0; i < EMOTES.length; i++) {
            double a = i * Math.PI * 2 / EMOTES.length - Math.PI / 2;
            int x = cx + (int) (Math.cos(a) * r), y = cy + (int) (Math.sin(a) * r);
            ctx.fill(x - 26, y - 11, x + 26, y + 11, i == hov ? 0xFF8A5CFF : 0xDD16161F);
            ctx.drawCenteredTextWithShadow(textRenderer, EMOTES[i], x, y - 4, 0xFFFFFFFF);
        }
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        int h = hovered(click.x(), click.y());
        if (h >= 0) { MinecraftClient.getInstance().player.networkHandler.sendChatMessage(SEND[h]); close(); return true; }
        return super.mouseClicked(click, doubled);
    }
}
