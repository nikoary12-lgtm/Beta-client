package dev.betaclient.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.*;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import dev.betaclient.module.Modules;

/**
 * Custom title screen. For the "very realistic" look, drop a high-res panorama/photo at
 * assets/betaclient/textures/gui/title_bg.png and draw it in render() (see TODO).
 */
public class BetaTitleScreen extends Screen {
    public BetaTitleScreen() { super(Text.literal("Beta Client")); }

    @Override protected void init() {
        int cx = width / 2 - 100, y = height / 2 - 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Singleplayer"), b -> client.setScreen(new SelectWorldScreen(this))).dimensions(cx, y, 200, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Multiplayer (Donut SMP)"), b -> client.setScreen(new MultiplayerScreen(this))).dimensions(cx, y + 26, 200, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Options"), b -> client.setScreen(new OptionsScreen(this, client.options))).dimensions(cx, y + 52, 98, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Quit"), b -> client.scheduleStop()).dimensions(cx + 102, y + 52, 98, 22).build());
    }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        // TODO: replace gradient with ctx.drawTexture(...) of your realistic background image.
        ctx.fillGradient(0, 0, width, height, 0xFF0B1020, 0xFF2B1A4F);
        float t = (System.currentTimeMillis() % 20000L) / 20000f;
        int glow = (int) (40 + 30 * Math.sin(t * Math.PI * 2));
        ctx.fillGradient(0, height - 90, width, height, 0x00000000, (glow << 24) | 0x8A5CFF);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(width / 2f, height / 2f - 70);
        ctx.getMatrices().scale(3f, 3f);
        ctx.drawCenteredTextWithShadow(textRenderer, "BETA CLIENT", 0, 0, Modules.rainbow(6f));
        ctx.getMatrices().popMatrix();
        super.render(ctx, mx, my, delta);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
}
