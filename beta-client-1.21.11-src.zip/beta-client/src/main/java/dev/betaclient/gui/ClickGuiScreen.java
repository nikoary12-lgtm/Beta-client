package dev.betaclient.gui;

import dev.betaclient.module.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.Click;
import net.minecraft.text.Text;
import java.util.*;

/** Click GUI: category panels, tap a module to toggle it. Touch-friendly sizes for Zalith. */
public class ClickGuiScreen extends Screen {
    public ClickGuiScreen() { super(Text.literal("Beta Client")); }

    private static final int W = 110, H = 20;

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        Map<String, List<Module>> cats = new LinkedHashMap<>();
        for (Module m : Modules.ALL) cats.computeIfAbsent(m.category, k -> new ArrayList<>()).add(m);
        int x = 20;
        for (var e : cats.entrySet()) {
            ctx.fill(x, 20, x + W, 20 + H, Modules.accent());
            ctx.drawCenteredTextWithShadow(textRenderer, e.getKey(), x + W / 2, 26, 0xFFFFFFFF);
            int y = 20 + H;
            for (Module m : e.getValue()) {
                boolean hover = mx >= x && mx <= x + W && my >= y && my < y + H;
                ctx.fill(x, y, x + W, y + H, hover ? 0xEE2A2A3A : 0xEE16161F);
                if (m.enabled) ctx.fill(x, y, x + 3, y + H, Modules.accent());
                ctx.drawTextWithShadow(textRenderer, m.name, x + 8, y + 6, m.enabled ? 0xFFFFFFFF : 0xFF999999);
                y += H;
            }
            x += W + 10;
        }
        super.render(ctx, mx, my, delta);
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        Map<String, List<Module>> cats = new LinkedHashMap<>();
        for (Module m : Modules.ALL) cats.computeIfAbsent(m.category, k -> new ArrayList<>()).add(m);
        int x = 20;
        for (var e : cats.entrySet()) {
            int y = 20 + H;
            for (Module m : e.getValue()) {
                if (mx >= x && mx <= x + W && my >= y && my < y + H) { m.toggle(); return true; }
                y += H;
            }
            x += W + 10;
        }
        return super.mouseClicked(click, doubled);
    }
}
