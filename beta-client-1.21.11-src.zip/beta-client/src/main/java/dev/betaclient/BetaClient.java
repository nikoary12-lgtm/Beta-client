package dev.betaclient;

import dev.betaclient.gui.*;
import dev.betaclient.module.Modules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class BetaClient implements ClientModInitializer {
    static KeyBinding guiKey, emoteKey;

    @Override public void onInitializeClient() {
        guiKey   = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.betaclient.gui",   GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        emoteKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.betaclient.emote", GLFW.GLFW_KEY_G,           KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.currentScreen instanceof TitleScreen) mc.setScreen(new BetaTitleScreen());
            while (guiKey.wasPressed())   mc.setScreen(new ClickGuiScreen());
            while (emoteKey.wasPressed()) if (mc.player != null) mc.setScreen(new EmoteWheelScreen());
            if (Modules.FULLBRIGHT.enabled) mc.options.getGamma().setValue(15.0);
        });

        HudRenderCallback.EVENT.register((ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            int y = 4;
            if (Modules.FPS_HUD.enabled)    { ctx.drawTextWithShadow(mc.textRenderer, mc.getCurrentFps() + " FPS", 4, y, Modules.accent()); y += 10; }
            if (Modules.COORDS_HUD.enabled) ctx.drawTextWithShadow(mc.textRenderer, String.format("XYZ %.0f %.0f %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, y, 0xFFFFFFFF);
        });
    }
}
