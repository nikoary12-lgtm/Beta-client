package dev.betaclient.module;

import java.util.List;

public class Modules {
    public static final Module CUSTOM_SKY     = new Module("Custom Sky", "Visual", true);
    public static final Module BLOCK_OUTLINE  = new Module("Custom Block Outline", "Visual", true);
    public static final Module CUSTOM_GLINT   = new Module("Custom Glint", "Visual", true);
    public static final Module FPS_HUD        = new Module("FPS / Ping HUD", "HUD", true);
    public static final Module COORDS_HUD     = new Module("Coordinates HUD", "HUD", true);
    public static final Module ZOOM           = new Module("Zoom (C)", "Utility", true);
    public static final Module FULLBRIGHT     = new Module("Fullbright (gamma)", "Utility", false);
    public static final List<Module> ALL = List.of(CUSTOM_SKY, BLOCK_OUTLINE, CUSTOM_GLINT, FPS_HUD, COORDS_HUD, ZOOM, FULLBRIGHT);

    // Theme colour (ARGB) used across the client. Rainbow-cycles for the outline.
    public static int accent() { return 0xFF8A5CFF; }
    public static int rainbow(float speed) {
        float h = (System.currentTimeMillis() % (long)(speed * 1000)) / (speed * 1000f);
        return 0xFF000000 | java.awt.Color.HSBtoRGB(h, 0.7f, 1f);
    }
}
