package dev.betaclient.mixin;

import dev.betaclient.module.Modules;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom sky colour. NOTE: sky/fog code moved around in 1.21.x; if this target fails, check the yarn name of the method that returns the sky colour. */
@Mixin(ClientWorld.class)
public class SkyColorMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true)
    private void beta$sky(Vec3d cameraPos, float tickProgress, CallbackInfoReturnable<Integer> cir) {
        if (Modules.CUSTOM_SKY.enabled) cir.setReturnValue(0xFF7B5CFF);
    }
}
